export class UKMModel {
    constructor(
        public id: string,
        public title: string,
        public description: string
    ) { }
}